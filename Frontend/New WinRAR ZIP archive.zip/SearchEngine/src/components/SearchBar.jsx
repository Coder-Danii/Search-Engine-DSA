import React from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Search } from 'lucide-react';

export function SearchBar() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const [query, setQuery] = React.useState(searchParams.get('q') || '');

    const handleSearch = (e) => {
        e.preventDefault();
        if (query.trim()) {
            navigate(`/search?q=${encodeURIComponent(query)}`);
        }
    };

    return (
        <form onSubmit={handleSearch} className="w-full max-w-2xl">
            <div className="flex items-center gap-2 bg-brown-800 dark:bg-beige-100 rounded-full overflow-hidden shadow-lg border border-brown-300 dark:border-brown-700">
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search anything..."
                    className="flex-1 px-6 py-4 bg-transparent outline-none text-beige-100 dark:text-brown-800 placeholder:text-beige-200 dark:placeholder:text-brown-700"
                />
                <button
                    type="submit"
                    className="px-6 py-4 flex items-center gap-2 text-beige-100 dark:text-brown-800 hover:bg-brown-700 dark:hover:bg-beige-200 transition-colors"
                >
                    <Search size={20} />
                    <span>Explore</span>
                </button>
            </div>
        </form>
    );
}