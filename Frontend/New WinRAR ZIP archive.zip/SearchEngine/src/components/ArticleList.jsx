import axios from 'axios';
import React, { useEffect, useState } from 'react';

export function ArticleList({ articles }) {
    const [thumbnails, setThumbnails] = useState({});

    useEffect(() => {
        const fetchThumbnails = async () => {
            try {
                // Send a POST request to the backend server to scrape the images
                const response = await axios.post('http://localhost:5000/scrape-images', {
                    urls: articles.map((article) => article.url),
                });
                console.log(response)

                const thumbnailMap = {};
                response.data.imageUrls.forEach((item) => {
                    thumbnailMap[item.url] = item.image;
                });

                setThumbnails(thumbnailMap);
                console.log(thumbnailMap)
            } catch (error) {
                console.error('Error fetching thumbnails:', error);
            }
        };

        fetchThumbnails();
    }, [articles]);

    return (
        <div className="space-y-6">
            {articles.map((article) => (
                <article key={article.id} className="flex gap-6 p-4 bg-white dark:bg-brown-800 rounded-lg shadow-md border-2 border-brown-700 dark:border-beige-300">
                    <img
                        src={thumbnails[article.url] || 'https://via.placeholder.com/200'}
                        alt={article.title}
                        className="w-48 h-32 object-cover rounded-lg"
                    />
                    <div className="flex flex-col flex-1">
                        <h2 className="text-xl font-bold text-brown-800 dark:text-beige-100 mb-2">
                            {article.title}
                        </h2>
                        <p className="text-brown-600 dark:text-beige-300 mb-4 line-clamp-2">
                            {article.description}
                        </p>
                        <div className="mt-auto">
                            <span className="text-sm text-brown-500 dark:text-beige-200">
                                By {article.author}
                            </span>
                        </div>
                    </div>
                </article>
            ))}
        </div>
    );
}
