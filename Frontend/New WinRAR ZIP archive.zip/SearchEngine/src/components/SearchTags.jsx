import React from 'react';
import { Tag } from 'lucide-react';

export function SearchTags({ tags }) {
    return (
        <div className="flex flex-wrap gap-2 mb-8">
            {tags.map((tag, index) => (
                <div
                    key={index}
                    className="flex items-center gap-1 px-3 py-1 rounded-full bg-brown-800 dark:bg-beige-100 text-beige-100 dark:text-brown-800"
                >
                    <Tag size={14} />
                    <span className="text-sm font-medium">{tag}</span>
                </div>
            ))}
        </div>
    );
}