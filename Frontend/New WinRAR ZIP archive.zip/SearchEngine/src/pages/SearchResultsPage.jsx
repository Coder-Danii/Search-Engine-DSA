// src/pages/SearchResultsPage.jsx
import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { ThemeToggle } from '../components/ThemeToggle';
import { SearchHeader } from '../components/SearchHeader';
import { SearchTags } from '../components/SearchTags';
import { ArticleList } from '../components/ArticleList';
import { Pagination } from '../components/Pagination';

function SearchResultsPage() {
    const [searchParams] = useSearchParams();
    const [currentPage, setCurrentPage] = React.useState(1);
    const query = searchParams.get('q');

    // Mock data for testing - replace with real data
    const tags = ['Technology', 'Programming', 'Web Development', 'React', 'JavaScript'];
    const articles = [
        {
            id: 1,
            title: `${query} - Article 1: Understanding Mental Health`,
            description: 'An insightful article about mental health issues and coping mechanisms.',
            author: 'John Doe',
            url: 'https://medium.com/invisible-illness/mental-note-vol-24-969b6a42443f'  // Example URL
        },
        {
            id: 2,
            title: `${query} - Article 2: How the Pandemic Affects the Brain`,
            description: 'A deep dive into the pandemic’s effects on mental health.',
            author: 'Jane Smith',
            url: 'https://medium.com/age-of-awareness/how-the-pandemic-affects-our-brain-and-mental-health-ae2ec0a9fc1d'  // Example URL
        },
        {
            id: 3,
            title: `${query} - Article 3: Mind Your Nose`,
            description: 'Exploring the sensory role of the nose in daily life.',
            author: 'Sam Green',
            url: 'https://medium.com/neodotlife/mind-your-nose-f0b097d533bb'  // Example URL
        },
        {
            id: 4,
            title: `${query} - Article 4: The 4 Purposes of Dreams`,
            description: 'A scientific explanation of why we dream.',
            author: 'Alex White',
            url: 'https://medium.com/science-for-real/the-4-purposes-of-dreams-fc6719090e75'  // Example URL
        }
    ];

    return (
        <div className="min-h-screen bg-beige-100 dark:bg-brown-900 transition-colors">
            <ThemeToggle />
            <div className="container mx-auto px-4 py-6">
                <SearchHeader />
                <SearchTags tags={tags} />
                <ArticleList articles={articles} />
                <Pagination
                    currentPage={currentPage}
                    totalPages={5}
                    onPageChange={setCurrentPage}
                />
            </div>
        </div>
    );
}

export default SearchResultsPage;
