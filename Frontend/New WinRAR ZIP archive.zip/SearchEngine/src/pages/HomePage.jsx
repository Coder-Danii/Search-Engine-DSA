import React from 'react';
import { MustacheIcon } from '../components/MustacheIcon';
import { SearchBar } from '../components/SearchBar';
import { ThemeToggle } from '../components/ThemeToggle';

function HomePage() {
    return (
        <div className="min-h-screen bg-beige-100 dark:bg-brown-900 transition-colors">
            <ThemeToggle />
            <div className="container mx-auto px-4 py-20">
                <div className="flex flex-col items-start gap-1 mb-8 ml-8">
                    {/* Text Section */}
                    <h1
                        className="text-6xl font-bold text-brown-800 dark:text-beige-100"
                        style={{ marginLeft: '263px' }}
                    >
                        mid.
                    </h1>
                    <p
                        className="text-lg text-brown-600 dark:text-beige-300 italic"
                        style={{ marginLeft: '266px' }}
                    >
                        your average search engine
                    </p>
                </div>

                {/* Icon and Search Bar Section */}
                <div className="relative">
                    {/* Icon Section */}
                    <div
                        className="absolute right-4 -top-12 w-12 h-12 rounded-full bg-brown-800 dark:bg-beige-100 flex items-center justify-center" style={{marginTop:'-50px', marginRight:'284px'}}
                    >
                        <MustacheIcon className="w-8 h-8 text-beige-100 dark:text-brown-800" />
                    </div>

                    {/* Search Bar */}
                    <div className="flex justify-center">
                        <SearchBar />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default HomePage;
