/** @type {import('tailwindcss').Config} */
export default {
    content: ['./index.html', './src/**/*.{js,jsx}'],
    darkMode: 'class',
    theme: {
        extend: {
            fontFamily: {
                poppins: ['Poppins', 'sans-serif'],
            },
            colors: {
                beige: {
                    100: '#F5F5DC',
                    200: '#E8E8D1',
                    300: '#DCDCC5',
                },
                brown: {
                    700: '#5D4037',
                    800: '#4E342E',
                    900: '#3E2723',
                },
            },
        },
    },
    plugins: [],
};